package com.example.googlemapsapp;

public class MyLocationListenerImpl extends MyLocationListener {
}
