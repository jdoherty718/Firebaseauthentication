package com.example.mysqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register1 extends AppCompatActivity {
    EditText name, pass, confirm;
    Button registerbtn;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register1);

        db = new DatabaseHelper(this);

        name = (EditText) findViewById(R.id.edit_newName);
        pass = (EditText) findViewById(R.id.edit_newPassword);
        confirm = (EditText) findViewById(R.id.edit_confirmPassword);

        registerbtn = (Button) findViewById(R.id.btnRegister2);
        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name_s = name.getText().toString();
                String pass_s = pass.getText().toString();
                String confirm_s = confirm.getText().toString();

                if (name_s.equals("") || pass_s.equals("") || confirm_s.equals("")) {
                    Toast.makeText(getApplicationContext(), "Missing info", Toast.LENGTH_SHORT).show();
                } else {
                    if (pass_s.equals(confirm_s)) {
                        Boolean checkEmail = db.checkEmail(name_s);
                        if (checkEmail == true) {
                            Boolean insert = db.insert(name_s, pass_s);
                            if (insert == true) {
                                Toast.makeText(getApplicationContext(), "Account Registered!", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getApplicationContext(), "Account already exists!", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(getApplicationContext(), "Passwords don't match!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}