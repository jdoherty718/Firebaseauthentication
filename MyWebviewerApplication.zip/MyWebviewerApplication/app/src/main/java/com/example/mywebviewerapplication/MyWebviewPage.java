package com.example.mywebviewerapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class MyWebviewPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_webview_page);

        WebView webview = new WebView(this);
        setContentView(webview);
        webview.loadUrl("https://www.ulster.ac.uk");
    }
}