package com.example.mywebviewerapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.SearchManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public static final String ExtraMessage = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    public void searchFor(View view) {
        String searchFor = ((EditText) findViewById(R.id.edit_Search)).getText().toString();
        Intent viewSearch = new Intent(this, MyWebviewPage.class);
        viewSearch.putExtra(ExtraMessage, searchFor);
        startActivity(viewSearch);
    }

    private boolean checkPermission(String permission) {
        int permissionCheck = ContextCompat.checkSelfPermission(this, permission);
        return (permissionCheck == PackageManager.PERMISSION_GRANTED);
    }

    public void dialPhone(View view) {
        String number = "123456789";
        if (checkPermission("android.permission.CALL_PHONE")==false){
            Toast toast = Toast.makeText(this, "You don't have permission!",Toast.LENGTH_SHORT);
            toast.show();
        }
        else{
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel: " + number));
            startActivity(intent);
        }
    }

    public void OpenSMS(View view) {
        Intent openSMS = new Intent(this, openSMS.class);
        startActivity(openSMS);
    }



}